//React-router-dom
import { useState } from "react";
import { createBrowserRouter, createRoutesFromElements, Route, RouterProvider } from "react-router-dom";

//Components
import Header from "./components/header/Header";
import Error from "./components/error/Error";

//Pages
import About from './pages/about/About'
import Home from "./pages/home/Home";
//layout
import RootLayout from "./layout/RootLayout";

function App() {
  const [mode, setMode] = useState(false);
   const routes =  createBrowserRouter(
    createRoutesFromElements(
      <Route path="/" element={<RootLayout setMode={setMode} mode={mode}/>}>
       <Route index element={<Home/>}/>
       <Route path="/about/:id" element={<About/>} />
       <Route path="*" element={<Error/>} />
      </Route>
    )
  )
  return (
    <div className={`App ${mode ? "dark" : "light"}`}>
      <RouterProvider router={routes}/>
    </div>
  
  );
}

export default App;
