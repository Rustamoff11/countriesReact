//rrd
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import Loader from "../../components/loader/Loader";
import './About.css'

import { useFetch } from "../../hooks/useFetch";

function About() {
  const { id } = useParams();
  
  const url = "https://countries-api-v7sn.onrender.com/countries/slug/" + id;
  console.log(url)
  const { data, loading, error } = useFetch(url);
  console.log(data);
  if (loading) {
    return (
      <Loader />
    );
  }

  if (error) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <h1>{error}</h1>
      </div>
    );
  }
  return (
    <div className="container">
      <Link className="btn" to="/">
        ← Back
      </Link>

      {data &&
       <div className="option-desp">
       <img className="country-img" src={data.flags.svg} alt="" />
       <div className="vest-oft">
         <h2 className="desp-title">{data.name.common}</h2>
         <div className="desp-wrap">
           <div className="inf-wrappers">
             <p>
               <b>Native name: </b> {data.name.common}
             </p>
             <p>
               <b>Population: </b> {data.population}
             </p>
             <p>
               <b>Region: </b> {data.region}
             </p>
             <p>
               <b>Sub Region: </b> {data.subregion}
             </p>
             <p>
               <b>Capital: </b> {data.capital}
             </p>
           </div>

           <div className="conf-wrappers">
             <p>
               <b>Top Level Domain: </b> {data.tld}
             </p>
             <p>
               <b>Currencies: </b> {data.currencies.map((e) => e)}
             </p>
             <p>
               <b>Languages: </b> {data.languages.map((e) => e)}
             </p>
           </div>
           <div className="borders">
             <b>Border Countries: </b>
             {data.borders
               ? data.borders.map((border) => {
                   return (
                     <Link
                       key={Math.random()}
                       to={`/about/${border.slug}`}
                       className="bord-country"
                     >
                       {border.common}
                     </Link>
                   );
                 })
               : " NO option"}
           </div>
         </div>
       </div>
     </div>
}
    </div>
  );
}

export default About;
