import './Home.css'

import { Link } from "react-router-dom";

import { useFetch } from "../../hooks/useFetch";
//component
import Filter from '../../components/filter/Filter';
import Loader from '../../components/loader/Loader';
import { useState } from 'react';
function Home() {
  const [limit, setLimit] = useState(250)
  let url = "https://countries-api-v7sn.onrender.com/countries?limit=" + limit
  const [search, setSearch ] = useState('')
  
  const {
    data,
    loading,
    error
  } = useFetch(search ? search : url);
  if (loading) {
    return (
      <Loader/>
    );
  }

  if (error) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <h1>{error}</h1>
      </div>
    );
  }
  return (
    <div>
      <Filter
      setSearch={setSearch}
      />
      <div className="container home-container">
        <div className="home_container">
          {data &&
            data.data.map((country, i) => {
              return (
                <Link key={i} className="homs" to={`/about/${country.name.slug}`}>
                  <img className="home-img" src={`${country.flags.png}`} alt="" />
                  <div className="home-body ">
                    <h5 className="home-title">{country.name.common}</h5>
                    <p>
                      <b>Population:</b> {country.population}
                    </p>
                    <p>
                      <b>Region:</b> {country.region}
                    </p>
                    <p>
                      <b>Capital:</b> {country.capital ? country.capital : "No capital"}
                    </p>
                  </div>
                </Link>
              );
            })}
        </div>
      </div>
    </div>
  );
}

export default Home;
