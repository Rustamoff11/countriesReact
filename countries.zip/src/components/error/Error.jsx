//css
import "./Error.css";
import { Link } from "react-router-dom";
import errorImage from "../../assets/notfound.jpg";
function Error() {
  return (
    <div className="novice error">
      <img src={errorImage} alt="Error" className="error-image" />
      <Link to="/" className="error-btn">
        Home
      </Link>
    </div>
  );
}

export default Error;
