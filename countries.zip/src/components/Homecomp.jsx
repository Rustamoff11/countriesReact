import React from 'react'
import { Link } from 'react-router-dom'

const HomeComponent = ({data}) => {
  return (
    <div className="container home-container">
        <div className="cards-container">
          {data &&
            data.data.map((country, i) => {
              return (
                <Link key={i} className="card" to={`/about/${country.name.slug}`}>
                  <img className="card-img" src={`${country.flags.png}`} alt="" />
                  <div className="card-body ">
                    <h5 className="card-title">{country.name.common}</h5>
                    <p>
                      <b>Population:</b> {country.population}
                    </p>
                    <p>
                      <b>Region:</b> {country.region}
                    </p>
                    <p>
                      <b>Capital:</b> {country.capital ? country.capital : "No capital"}
                    </p>
                  </div>
                </Link>
              );
            })}
        </div>
      </div>
  )
}

export default HomeComponent