import React from 'react'
import { Outlet } from 'react-router-dom'
import Header from '../components/header/Header'

const RootLayout = ({setMode, mode}) => {
  return (
    <>
    <Header setMode={setMode} mode={mode}/>
    <main>
        <Outlet/>
    </main>
    </>
  )
}

export default RootLayout